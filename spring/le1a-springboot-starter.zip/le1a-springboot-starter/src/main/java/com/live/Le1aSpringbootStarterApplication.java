package com.live;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Le1aSpringbootStarterApplication {

	public static void main(String[] args) {
		SpringApplication.run(Le1aSpringbootStarterApplication.class, args);
	}

}
